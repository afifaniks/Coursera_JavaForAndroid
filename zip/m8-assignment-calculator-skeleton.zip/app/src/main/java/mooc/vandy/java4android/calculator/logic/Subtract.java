package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Subtract operation.
 */
public class Subtract {
    // TODO -- start your code here
    int a;
    int b;

    public Subtract(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public int operation() {
        return a - b;
    }
}
