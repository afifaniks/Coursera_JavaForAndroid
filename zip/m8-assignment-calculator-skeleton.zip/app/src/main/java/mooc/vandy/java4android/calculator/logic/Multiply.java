package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Multiply operation.
 */
public class Multiply {
    // TODO -- start your code here
    int a;
    int b;

    public Multiply(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public int operation() {
        return a * b;
    }
}
