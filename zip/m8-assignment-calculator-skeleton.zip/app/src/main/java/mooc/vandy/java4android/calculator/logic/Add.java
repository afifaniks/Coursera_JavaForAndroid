package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Add operation.
 */
public class Add {
    // TODO -- start your code here
    int a;
    int b;

    public Add(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public int operation() {
        return a + b;
    }
}
